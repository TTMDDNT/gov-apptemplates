/*! For license information please see bundle.js.LICENSE.txt */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;(()=>{"use strict";var e={d:(t,r)=>{for(var a in r)e.o(r,a)&&!e.o(t,a)&&Object.defineProperty(t,a,{enumerable:!0,get:r[a]})},o:(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r:e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})}},t={};e.r(t),e.d(t,{IFrameControl:()=>r});class r{init(e,t,r,a){this._container=a,this._controlViewRendered=!1}updateView(e){this._controlViewRendered||(this._controlViewRendered=!0,this.renderIFrame());var t=e.parameters.target.raw;this._Target!=t&&(this._Target=t||"",this._iframe.setAttribute("src",this._Target))}renderIFrame(){var e=document.createElement("iframe");e.setAttribute("class","pcf-ctrl-iframe"),e.setAttribute("frameborder","0"),this._iframe=e,this._container.appendChild(this._iframe)}getOutputs(){return{}}destroy(){}}pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=t})();
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MicrosoftPCF.IFrameControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IFrameControl);
} else {
	var MicrosoftPCF = MicrosoftPCF || {};
	MicrosoftPCF.IFrameControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IFrameControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}